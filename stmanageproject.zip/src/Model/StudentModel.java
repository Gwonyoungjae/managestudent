package Model;

public class StudentModel {
	private int Stu_no; //�л���ȣ
    private String S_name; //�л��̸�
	private String A_grade; //�������
  /*  private String s_date;*/
    private String S_Subject; //���ð���
    private String S_grade; //�л��г�
    private String ban;  //�л���
    private String S_uni;  //��ǥ����
    private String S_ati;  //�л��µ�
	
    
    public StudentModel() {
		super();
	}
	
	public StudentModel(int stu_no, String s_name, String a_grade, String s_Subject, String s_grade, String ban,
			String s_uni) {
		super();
		Stu_no = stu_no;
		S_name = s_name;
		A_grade = a_grade;
		S_Subject = s_Subject;
		S_grade = s_grade;
		ban = ban;
		S_uni = s_uni;
	}
	public StudentModel(int stu_no, String s_name, String a_grade, String s_Subject, String s_grade, String ban,
			String s_uni, String s_ati) {
		super();
		this.Stu_no = stu_no;
		this.S_name = s_name;
		this.A_grade = a_grade;
		this.S_Subject = s_Subject;
		this.S_grade = s_grade;
		this.ban = ban;
		this.S_uni = s_uni;
		this.S_ati = s_ati;
	}
	public StudentModel(int stu_no, String s_name, String a_grade, String s_Subject, String s_grade, String ban) {
		super();
		Stu_no = stu_no;
		S_name = s_name;
		A_grade = a_grade;
		S_Subject = s_Subject;
		S_grade = s_grade;
		ban = ban;
	}

	public int getStu_no() {
		return Stu_no;
	}

	public void setStu_no(int stu_no) {
		Stu_no = stu_no;
	}

	public String getS_name() {
		return S_name;
	}

	public void setS_name(String s_name) {
		S_name = s_name;
	}

	public String getA_grade() {
		return A_grade;
	}

	public void setA_grade(String a_grade) {
		A_grade = a_grade;
	}

	public String getS_Subject() {
		return S_Subject;
	}

	public void setS_Subject(String s_Subject) {
		S_Subject = s_Subject;
	}

	public String getS_grade() {
		return S_grade;
	}

	public void setS_grade(String s_grade) {
		S_grade = s_grade;
	}



	public String getBan() {
		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;
	}

	public String getS_uni() {
		return S_uni;
	}

	public void setS_uni(String s_uni) {
		S_uni = s_uni;
	}

	public String getS_ati() {
		return S_ati;
	}

	public void setS_ati(String s_ati) {
		S_ati = s_ati;
	}
	
}