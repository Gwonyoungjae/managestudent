package Model;

import java.sql.Date;

public class ManagerModel {	
	
private String ID;   //���̵�
private String PW;    //��й�ȣ	
private String stf_No; //������ȣ
private String t_Name; //�����̸�
private String dpManager; //�������
private String subject; //������
private String ImageView; //�������
private String f_grade; //�����з�
private String t_PHNO;  //�����ȣ
private String t_add;   //�����ּ�
private String ban;     //����

public ManagerModel() {
	super();
}



public ManagerModel(String stf_No, String t_Name, String dpManager, String subject, String imageView, String f_grade,
		String t_PHNO, String t_add, String ban) {
	super();
	this.stf_No = stf_No;
	this.t_Name = t_Name;
	this.dpManager = dpManager;
	this.subject = subject;
	ImageView = imageView;
	this.f_grade = f_grade;
	this.t_PHNO = t_PHNO;
	this.t_add = t_add;
	this.ban = ban;
}




public ManagerModel(String iD, String pW, String stf_No, String t_Name, String dpManager, String subject,
		String imageView, String f_grade, String t_PHNO, String t_add, String ban) {
	super();
	ID = iD;
	PW = pW;
	this.stf_No = stf_No;
	this.t_Name = t_Name;
	this.dpManager = dpManager;
	this.subject = subject;
	ImageView = imageView;
	this.f_grade = f_grade;
	this.t_PHNO = t_PHNO;
	this.t_add = t_add;
	this.ban = ban;
}



public String getID() {
	return ID;
}



public void setID(String iD) {
	ID = iD;
}



public String getPW() {
	return PW;
}



public void setPW(String pW) {
	PW = pW;
}



public String getStf_No() {
	return stf_No;
}



public void setStf_No(String stf_No) {
	this.stf_No = stf_No;
}



public String getT_Name() {
	return t_Name;
}



public void setT_Name(String t_Name) {
	this.t_Name = t_Name;
}



public String getDpManager() {
	return dpManager;
}



public void setDpManager(String dpManager) {
	this.dpManager = dpManager;
}



public String getSubject() {
	return subject;
}



public void setSubject(String subject) {
	this.subject = subject;
}



public String getImageView() {
	return ImageView;
}



public void setImageView(String imageView) {
	ImageView = imageView;
}



public String getF_grade() {
	return f_grade;
}



public void setF_grade(String f_grade) {
	this.f_grade = f_grade;
}



public String getT_PHNO() {
	return t_PHNO;
}



public void setT_PHNO(String t_PHNO) {
	this.t_PHNO = t_PHNO;
}



public String getT_add() {
	return t_add;
}



public void setT_add(String t_add) {
	this.t_add = t_add;
}



public String getBan() {
	return ban;
}



public void setBan(String ban) {
	this.ban = ban;
}


}