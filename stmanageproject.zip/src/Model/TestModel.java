package Model;

import java.sql.Date;

public class TestModel {

    
    private String test_no; //�����ȣ	
    private String testDivi; //���豸��
   private String t_subject; //�������
    private String testDate;   //������
    private int korean;      //�������
    private int math;        //��������
    private int english;     //��������
    private String seek;     //Ž�� ����
    private int subseek;     //Ž�� ����
    private int Stu_no;
	public TestModel() {
		super();
	}
	


	public TestModel(String test_no, String testDivi, String t_subject, String testDate) {
		super();
		this.test_no = test_no;
		this.testDivi = testDivi;
		this.t_subject = t_subject;
		this.testDate = testDate;
	}



	public TestModel(String test_no, String testDivi, int korean, int math, int english, String seek, int subseek) {
		super();
		this.test_no = test_no;
		this.testDivi = testDivi;
		this.korean = korean;
		this.math = math;
		this.english = english;
		this.seek = seek;
		this.subseek = subseek;
	}





	public TestModel(String test_no, String testDivi, String t_subject, String testDate, int korean, int math,
			int english, String seek, int subseek, int stu_no) {
		super();
		this.test_no = test_no;
		this.testDivi = testDivi;
		this.t_subject = t_subject;
		this.testDate = testDate;
		this.korean = korean;
		this.math = math;
		this.english = english;
		this.seek = seek;
		this.subseek = subseek;
		this.Stu_no = stu_no;
	}



	public String getTest_no() {
		return test_no;
	}



	public void setTest_no(String test_no) {
		this.test_no = test_no;
	}



	public String getTestDivi() {
		return testDivi;
	}



	public void setTestDivi(String testDivi) {
		this.testDivi = testDivi;
	}



	public String getT_subject() {
		return t_subject;
	}



	public void setT_subject(String t_subject) {
		this.t_subject = t_subject;
	}



	public String getTestDate() {
		return testDate;
	}



	public void setTestDate(String testDate) {
		this.testDate = testDate;
	}



	public int getKorean() {
		return korean;
	}



	public void setKorean(int korean) {
		this.korean = korean;
	}



	public int getMath() {
		return math;
	}



	public void setMath(int math) {
		this.math = math;
	}



	public int getEnglish() {
		return english;
	}



	public void setEnglish(int english) {
		this.english = english;
	}



	public String getSeek() {
		return seek;
	}



	public void setSeek(String seek) {
		this.seek = seek;
	}



	public int getSubseek() {
		return subseek;
	}



	public void setSubseek(int subseek) {
		this.subseek = subseek;
	}



	public int getStu_no() {
		return Stu_no;
	}



	public void setStu_no(int stu_no) {
		Stu_no = stu_no;
	}




	
}
