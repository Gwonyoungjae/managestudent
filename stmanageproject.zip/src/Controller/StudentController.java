package Controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.ManagerModel;
import Model.StudentModel;
import Model.TestModel;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class StudentController implements Initializable {
	@FXML
	private TextField txtStu_no;
	@FXML
	private TextField txtS_name;
	@FXML
	private TextField txtA_grade;
	@FXML
	private ComboBox<String> cbS_Subject;
	@FXML
	private ComboBox<String> cbS_grade;
	@FXML
	private ComboBox<String> cbban;
	@FXML
	private TextField txtS_uni;
	@FXML
	private TextArea txtS_ati;
	@FXML
	private Button btnS_chek;
	@FXML
	private Button btnS_Modi;
	@FXML
	private Button btnS_Search;
	@FXML
	private Button btnS_resiview;
	@FXML
	private Button btnS_delete;

	@FXML
	private Button btnS_close;
	@FXML
	private TableView<Model.StudentModel> S_subTableview = new TableView<>();
	@FXML
	private TableView<Model.TestModel> SS_TestTableview = new TableView<>();
	@FXML
	private TableView<Model.TestModel> S_TestTableview = new TableView<>();
	@FXML
	private TableView<Model.StudentModel> S_StudentTableview = new TableView<>();

	Model.StudentModel testModel = new Model.StudentModel();
	ObservableList<Model.StudentModel> data = FXCollections.observableArrayList();
	ObservableList<Model.StudentModel> selectTestModel = null; // ���̺����� ������ ���� ����
	Model.TestModel tmo =new Model.TestModel();
	ObservableList<Model.TestModel> data1 = FXCollections.observableArrayList();
	ObservableList<Model.TestModel> selectTestModel1 = null; // ���̺����� ������ ���� ����

	int selectedIndex;
	int no;

	String selectFileName = ""; // �̹��� ���ϸ�
	String localUrl = ""; // �̹��� ���� ���
	Image localImage;
	File selectedFile = null;
	// �̹��� ó��
	// �̹��� ������ ������ �Ű������� ���� ��ü ����

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		cbS_Subject.setItems(FXCollections.observableArrayList("��ü", "���", "����", "�ܱ���", "Ž������", "Ž����ȸ"));
		cbS_grade.setItems(FXCollections.observableArrayList("��ü", "1�г�", "2�г�", "3�г�"));
		cbban.setItems(FXCollections.observableArrayList("��ü", "A", "B", "C", "D", "E"));
		btnS_close.setOnAction(e -> Platform.exit());
		btnS_chek.setOnAction(event -> handlerBtnS_chekAction(event));
		btnS_Modi.setOnAction(event -> handlerBtnS_ModiAction(event));
		btnS_Search.setOnAction(event -> handlerBtnS_SearchAction(event));
		btnS_resiview.setOnAction(event -> handlerBtnS_resiviewAction(event));
		btnS_delete.setOnAction(event -> handlerBtnS_deleteAction(event));

		TableColumn colStu_no = new TableColumn("No");
		colStu_no.setMaxWidth(40);
		colStu_no.setStyle("-fx-allignment: CENTER");
		colStu_no.setCellValueFactory(new PropertyValueFactory<>("Stu_no"));
		TableColumn colS_name = new TableColumn("�л��̸�");
		colS_name.setMaxWidth(60);
		colS_name.setStyle("-fx-allignment: CENTER");
		colS_name.setCellValueFactory(new PropertyValueFactory<>("S_name"));

		TableColumn colA_grade = new TableColumn("�������");
		colA_grade.setMinWidth(50);
		colA_grade.setCellValueFactory(new PropertyValueFactory<>("A_grade"));

		TableColumn colS_Subject = new TableColumn("����");
		colS_Subject.setMaxWidth(50);
		colS_Subject.setCellValueFactory(new PropertyValueFactory<>("S_Subject"));
		TableColumn colS_grade = new TableColumn("�г�");
		colS_grade.setMaxWidth(50);
		colS_grade.setCellValueFactory(new PropertyValueFactory<>("S_grade"));

		TableColumn colban = new TableColumn("��");
		colban.setMaxWidth(20);
		colban.setCellValueFactory(new PropertyValueFactory<>("ban"));
		TableColumn colS_uni = new TableColumn("��ǥ����");
		colS_uni.setMinWidth(40);
		colS_uni.setCellValueFactory(new PropertyValueFactory<>("S_uni"));

		S_StudentTableview.getColumns().addAll(colStu_no, colS_name, colA_grade, colS_Subject, colS_grade, colban,
				colS_uni);
		totalList();
		S_StudentTableview.setItems(data);

	TableColumn coltest_no = new TableColumn("No");
		coltest_no.setMaxWidth(40);
		coltest_no.setStyle("-fx-allignment: CENTER");
		coltest_no.setCellValueFactory(new PropertyValueFactory<>("test_no"));
		TableColumn coltestdivi = new TableColumn("���豸��");
		coltestdivi.setMinWidth(40);
		coltestdivi.setStyle("-fx-allignment: CENTER");
		coltestdivi.setCellValueFactory(new PropertyValueFactory<>("testDivi"));

		TableColumn colt_subject = new TableColumn("����");
		colt_subject.setMinWidth(50);
		colt_subject.setCellValueFactory(new PropertyValueFactory<>("t_subject"));

		TableColumn coltestdate = new TableColumn("���ó�¥");
		coltestdate.setMaxWidth(150);
		coltestdate.setCellValueFactory(new PropertyValueFactory<>("testDate"));
		
		S_TestTableview.getColumns().addAll(coltest_no, coltestdivi, colt_subject, coltestdate);
		totalList1();
		S_TestTableview.setItems(data1);


		S_StudentTableview.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				selectTestModel = S_StudentTableview.getSelectionModel().getSelectedItems();
				selectedIndex = S_StudentTableview.getSelectionModel().getSelectedIndex();
				no = selectTestModel.get(0).getStu_no();
				try {
					txtStu_no.setText(selectTestModel.get(0).getStu_no() + "");
					txtS_name.setText(selectTestModel.get(0).getS_name());
					txtA_grade.setText(selectTestModel.get(0).getA_grade());
					txtS_ati.setText(selectTestModel.get(0).getS_ati());
					txtS_uni.setText(selectTestModel.get(0).getS_uni());
					cbS_Subject.setValue((String) selectTestModel.get(0).getS_Subject());
					cbS_grade.setValue((String) selectTestModel.get(0).getS_grade());
					cbban.setValue((String) selectTestModel.get(0).getBan());

				} catch (Exception e) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("���� ���� ���� ����");
					alert.setHeaderText("���� ������ �Է��Ͻÿ�.");
					alert.setContentText("�������� �����ϼ���!");
					alert.showAndWait();
				}
			}
		});
	}

	public void totalList1() {
		
			Object[][] totalData;
			TestDao sDao = new TestDao();
			TestModel sto = new TestModel();
			ArrayList<String> title;
			ArrayList<TestModel> list;
			title = sDao.getColumnName();
			int columnCount = title.size();
			list = sDao.getTestTotal();

			int rowCount = list.size();
			System.out.println(rowCount);
			totalData = new Object[rowCount][columnCount];

			for (int index = 0; index < rowCount; index++) {
				sto = list.get(index);
				System.out.println(sto.getStu_no());
				data1.add(sto);
		
		}
	}
	public void handlerBtnS_deleteAction(ActionEvent event) {

		StudentDao sDao = new StudentDao();
		StudentModel sVo = new StudentModel();

		try {

			sDao.getStudent(no);

			data.removeAll(data);
			// �л� ��ü ����
			totalList();
			init();
		} catch (Exception e) {
			System.out.println(e);

		}

	}

	// ����
	public void handlerBtndeleteAction(ActionEvent event) {
		StudentDao sDao = new StudentDao();
		StudentModel sVo = new StudentModel();

		try {

			sDao.getStudent(no);

			data.removeAll(data);
			// �л� ��ü ����
			totalList();
			init();
		} catch (Exception e) {
			System.out.println(e);

		}

		
	}

	public void init() {

		txtStu_no.clear();
		txtS_name.clear();
		cbS_Subject.getSelectionModel().clearSelection();
		txtA_grade.clear();
		txtS_uni.clear();
		txtS_ati.clear();
		cbban.getSelectionModel().clearSelection();
	}

	public void handlerBtnS_resiviewAction(ActionEvent event) {
		
		try {
			FXMLLoader sloader = new FXMLLoader();

			sloader.setLocation(getClass().getResource("/View/StudentCheck.fxml"));

			Stage dialogS = new Stage(StageStyle.UTILITY);

			dialogS.initModality(Modality.WINDOW_MODAL);
			dialogS.initOwner(btnS_resiview.getScene().getWindow());
			dialogS.setTitle("�л�������ȸ");
			Parent parentEdit = (Parent) sloader.load();
			Model.StudentModel Studentview = S_StudentTableview.getSelectionModel().getSelectedItem();
			selectedIndex = S_StudentTableview.getSelectionModel().getSelectedIndex();
System.out.println(Studentview.getBan());
			TextField editStu_no = (TextField) parentEdit.lookup("#txtStu_no");
			TextField editS_name = (TextField) parentEdit.lookup("#txtS_name ");
			TextField editA_grade = (TextField) parentEdit.lookup("#txtA_grade");
			ComboBox editS_Subject = (ComboBox) parentEdit.lookup("#cbS_Subject");
			ComboBox editS_grade = (ComboBox) parentEdit.lookup("#cbS_grade");
			ComboBox editban = (ComboBox) parentEdit.lookup("#cbban");
			TextField editS_uni = (TextField) parentEdit.lookup("#txtS_uni");
			TextField editS_ati = (TextField) parentEdit.lookup("#txtS_ati");
     TableView <Model.TestModel>SS_TestTableview=(TableView) parentEdit.lookup("#SS_TestTableview");
			editStu_no.setDisable(true);
			editS_name.setDisable(true);
			editA_grade.setDisable(true);
			editS_Subject.setDisable(true);
			editS_grade.setDisable(true);
			//editban.setDisable(true);
			editS_uni.setDisable(true);
			editS_ati.setDisable(true);
 
			
			TableColumn coltest_no = new TableColumn("No");
			coltest_no.setMaxWidth(40);
			coltest_no.setStyle("-fx-allignment: CENTER");
			coltest_no.setCellValueFactory(new PropertyValueFactory<>("test_no"));
			TableColumn coltestdivi = new TableColumn("���豸��");
			coltestdivi.setMinWidth(40);
			coltestdivi.setStyle("-fx-allignment: CENTER");
			coltestdivi.setCellValueFactory(new PropertyValueFactory<>("testDivi"));

			TableColumn colt_subject = new TableColumn("����");
			colt_subject.setMinWidth(50);
			colt_subject.setCellValueFactory(new PropertyValueFactory<>("t_subject"));

			TableColumn coltestdate = new TableColumn("���ó�¥");
			coltestdate.setMaxWidth(150);
			coltestdate.setCellValueFactory(new PropertyValueFactory<>("testDate"));
			
			SS_TestTableview.getColumns().addAll(coltest_no, coltestdivi, colt_subject, coltestdate);
			System.out.println("a");
			totalList1();
			System.out.println("b");
			SS_TestTableview.setItems(data1);
			editStu_no.setText(Studentview.getStu_no() + "");
			editS_name.setText(Studentview.getS_name());
			editA_grade.setText(Studentview.getA_grade());
			System.out.println(Studentview.getBan());
			editS_Subject.setValue(Studentview.getS_Subject());
			editS_grade.setValue(Studentview.getS_grade());
			editban.setValue(Studentview.getBan());
			System.out.println(editban.getUserData()+"���");
			Button btnS_close = (Button) parentEdit.lookup("#btnS_close");

			btnS_close.setOnAction(e -> {
				dialogS.close();
			});
			Scene scene = new Scene(parentEdit);
			dialogS.setScene(scene);
			dialogS.setResizable(false);
			dialogS.show();
		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}

	public void handlerBtnS_SearchAction(ActionEvent event) {

	}

	public void handlerBtnS_ModiAction(ActionEvent event) {

		
			StudentModel sVo = null;
			StudentDao sDao = null;
			StudentModel TestEdit = S_StudentTableview.getSelectionModel().getSelectedItem();
			selectedIndex = S_StudentTableview.getSelectionModel().getSelectedIndex();

		
		
			if (event.getSource().equals(btnS_Modi)) {
				sVo = new StudentModel(Integer.parseInt(txtStu_no.getText().trim()), txtS_name.getText(),
						txtA_grade.getText(), cbS_Subject.getSelectionModel().getSelectedItem(),
						cbS_grade.getSelectionModel().getSelectedItem(), cbban.getSelectionModel().getSelectedItem(),
						txtS_uni.getText(), txtS_ati.getText());
				sDao = new StudentDao();
				

				try {
					sDao.getTestUpdate(sVo, sVo.getStu_no());
				} catch (Exception e) {

					e.printStackTrace();
				}
				data.removeAll(data);
				totalList();
			}
		}

	// ��ü����Ʈ
	public void totalList() {
		Object[][] totalData3;
		StudentDao sDao = new StudentDao();
		StudentModel sVo = new StudentModel();
		ArrayList<String> title;
		ArrayList<StudentModel> list;
		title = sDao.getColumnName();
		int columnCount = title.size();
		list = sDao.getStudentTotal();

		int rowCount = list.size();

		totalData3 = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			sVo = list.get(index);
			data.add(sVo);
		System.out.println(sVo.getBan());	
		}
		
	}

	public void handlerBtnS_chekAction(ActionEvent event) {
		try {

			StudentModel svo = null;
			StudentDao sDao = null;

			
			
			if (event.getSource().equals(btnS_chek)) {
				svo = new StudentModel(Integer.parseInt(txtStu_no.getText().trim()), txtS_name.getText(),
						txtA_grade.getText(), cbS_Subject.getSelectionModel().getSelectedItem(),
						cbS_grade.getSelectionModel().getSelectedItem(), cbban.getSelectionModel().getSelectedItem(),
						txtS_uni.getText(), txtS_ati.getText());
				sDao = new StudentDao();
				sDao.getStudentregiste(svo);

				if (sDao != null) {
					totalList();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("�л� ���� �Է�");
					alert.setHeaderText(txtS_name.getText() + " �л��� ������ ���������� �߰��Ǿ����ϴ�..");
					alert.setContentText("���� �л��� ������ �Է��ϼ���");
					alert.showAndWait();

					txtStu_no.clear();
					txtS_name.clear();
					cbS_Subject.getSelectionModel().clearSelection();
					cbS_grade.getSelectionModel().clearSelection();

					txtA_grade.clear();

					txtS_uni.clear();
					txtS_ati.clear();
					cbban.getSelectionModel().clearSelection();
				}
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�л� ���� �Է�");
				alert.setHeaderText("���� ������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
		} catch (Exception e) {
			e.getStackTrace();

		}
	}
}
