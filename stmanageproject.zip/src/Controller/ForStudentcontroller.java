package Controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.sun.javafx.scene.control.SelectedCellsMap;

import Model.TestModel;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.SelectionModel;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ForStudentcontroller implements Initializable {
	@FXML
	private TextField txtTestNo;
	@FXML
	private ComboBox<String> cbTestdivi;
	@FXML
	private ComboBox<String> cbsubjectdivi;

	@FXML
	private TextField txtStu_num;
	@FXML
	private DatePicker dptest;
	@FXML
	private TextField txtkorean;
	@FXML
	private TextField txtmath;
	@FXML
	private TextField txtenglish;
	@FXML
	private ComboBox<String> cbsubdivi;
	@FXML
	private TextField txtsubdivi;
	@FXML
	private Button btnok;
	@FXML
	private Button btnreok;
	@FXML
	private Button btnma_view;
	@FXML
	private Button btnclose;
	@FXML
	private Button btnTmodi;
	@FXML
	private Button btndelete;
	@FXML
	private Button btnbarchart;
	@FXML
	private Button btnlinechart;

	@FXML
	private Button btnst_view;
	@FXML
	private TextField txtTNSearch;
	@FXML
	private ComboBox<String> cbTDSearch;
	@FXML
	private ComboBox<String> cbSDSearch;
	@FXML
	private TextField txtSNSearch;
	@FXML
	private DatePicker dpsearch;
	@FXML
	private Button btnSearch;
	@FXML
	private TableView<Model.TestModel> totaltableview = new TableView<>();

	Model.TestModel testModel = new Model.TestModel();
	ObservableList<Model.TestModel> data = FXCollections.observableArrayList();
	ObservableList<Model.TestModel> selectTestModel = null; // ���̺����� ������ ���� ����

	String no;

	int selectedIndex;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// combobox ���� ,��ư ����
		cbTestdivi.setItems(FXCollections.observableArrayList("��ü", "������", "������", "���ǰ���", "���ɱ���"));
		cbTDSearch.setItems(FXCollections.observableArrayList("��ü", "������", "������", "���ǰ���", "���ɱ���"));
		cbsubjectdivi.setItems(FXCollections.observableArrayList("��ü", "���", "����", "�ܱ���", "Ž������", "Ž����ȸ"));
		cbSDSearch.setItems(FXCollections.observableArrayList("��ü", "���", "����", "�ܱ���", "Ž������", "Ž����ȸ"));
		cbsubdivi.setItems(FXCollections.observableArrayList("��ȸ", "����"));
		btnclose.setOnAction(e -> Platform.exit());
		btnbarchart.setOnAction(event -> handlerBtnbarchartAction(event));
	//	btnlinechart.setOnAction(event -> handlerBtnlinechartAction(event));
		btnSearch.setOnAction(event -> handlerBtnSearchAction(event));
		btnst_view.setOnAction(event -> handlerBtnst_viewAction(event));
		btnma_view.setOnAction(event -> handlerBtnma_viewAction(event));
		btnreok.setOnAction(event -> handlerBtnreokAction(event));
		btndelete.setOnAction(event -> handlerBtndeleteAction(event));
		btnok.setOnAction(event -> handlerBtnokAction(event));
		btnTmodi.setOnAction(event -> handlerBtnTmodiAction(event));
		// ��¥ ����� ����
		dptest.setValue(LocalDate.now());

		// �л������ǿ� �ִ� �������� ���̺�
		TableColumn colTestNo = new TableColumn("No");
		colTestNo.setMaxWidth(40);
		colTestNo.setStyle("-fx-allignment: CENTER");
		colTestNo.setCellValueFactory(new PropertyValueFactory<>("test_no"));
		TableColumn colTestdivi = new TableColumn("���豸��");
		colTestdivi.setMaxWidth(60);
		colTestdivi.setStyle("-fx-allignment: CENTER");
		colTestdivi.setCellValueFactory(new PropertyValueFactory<>("testDivi"));

		TableColumn colkorean = new TableColumn("���");
		colkorean.setMaxWidth(50);
		colkorean.setCellValueFactory(new PropertyValueFactory<>("korean"));

		TableColumn colmath = new TableColumn("����");
		colmath.setMaxWidth(50);
		colmath.setCellValueFactory(new PropertyValueFactory<>("math"));
		TableColumn colenglish = new TableColumn("�ܱ���");
		colenglish.setMaxWidth(50);
		colenglish.setCellValueFactory(new PropertyValueFactory<>("english"));
		TableColumn colseek = new TableColumn("Ž������");
		colseek.setMinWidth(35);
		colseek.setCellValueFactory(new PropertyValueFactory<>("seek"));
		TableColumn colsubseek = new TableColumn("Ž��");
		colsubseek.setMaxWidth(50);
		colsubseek.setCellValueFactory(new PropertyValueFactory<>("subseek"));

		totaltableview.getColumns().addAll(colTestNo, colTestdivi, colkorean, colmath, colenglish, colseek, colsubseek);
		totalList();

		totaltableview.setItems(data);

		totaltableview.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {

				selectTestModel = totaltableview.getSelectionModel().getSelectedItems();
				selectedIndex = totaltableview.getSelectionModel().getSelectedIndex();

				no = selectTestModel.get(0).getTest_no();

			}

		});
	}

/*	public void handlerBtnlinechartAction(ActionEvent event) {
		selectTestModel = totaltableview.getSelectionModel().getSelectedItems();
		no = selectTestModel.get(0).getTestDivi();
		selectFileName = selectTestModel.get(0).getStu_no()+"";
		localUrl = "file:/C:/images/" + selectFileName;
		localImage = new Image(localUrl, false);
	}
*/
	public void handlerBtnbarchartAction(ActionEvent event) {
		
	}

	// ����
	public void handlerBtndeleteAction(ActionEvent event) {
		TestDao sDao = new TestDao();
		TestModel sVo = new TestModel();

		selectTestModel.get(0).getTest_no();
		try {

			sDao.getTest2(no);

			data.removeAll(data);
			// �л� ��ü ����
			totalList();
			init();
		} catch (Exception e) {
			System.out.println(e);

		}

	}

	public void handlerBtnTmodiAction(ActionEvent event) {
		totaltableview.getOnMousePressed();
		try {
			txtTestNo.setText(selectTestModel.get(0).getTest_no());
			cbTestdivi.setValue((String) selectTestModel.get(0).getTestDivi());
			cbsubjectdivi.setValue((String) selectTestModel.get(0).getT_subject());
			dptest.setUserData((String) selectTestModel.get(0).getTestDate());
			txtkorean.setText(selectTestModel.get(0).getKorean() + "");
			txtmath.setText(selectTestModel.get(0).getMath() + "");
			txtenglish.setText(selectTestModel.get(0).getEnglish() + "");
			cbsubdivi.setValue((String) selectTestModel.get(0).getSeek());
			txtsubdivi.setText(selectTestModel.get(0).getSubseek() + "");
			txtStu_num.setText(selectTestModel.get(0).getStu_no() + "");

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� ���� ���� ����");
			alert.setHeaderText("���� ������ �Է��Ͻÿ�.");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();
		}

	}

	// �˻� �޼ҵ�
	public void handlerBtnSearchActoion(ActionEvent event) {
		TestModel sVo = new TestModel();
        TestDao sDao = null;
		Object[][] totalData = null;
		String searchName = "";
		boolean searchResult = false;
		try {
			searchName = txtTestNo.getText().trim();
			sDao = new TestDao();
			sVo = sDao.getStudentCheck(searchName);
			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�л� ���� �˻�");
				alert.setHeaderText("�л��� �̸��� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
			if (!searchName.equals("") && (sVo != null)) {
				ArrayList<String> title;
				ArrayList<TestModel> list;
				title = sDao.getColumnName();
				int columnCount = title.size();
				list = sDao.getTestTotal();
				int rowCount = list.size();
				totalData = new Object[rowCount][columnCount];
				if (sVo.getTest_no().equals(searchName)) {
					txtTestNo.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						System.out.println(index);
						sVo = list.get(index);
						if (sVo.getTest_no().equals(searchName)) {
							data.add(sVo);
							searchResult = true;
						}
					}
				}
			}
			if (!searchResult) {
				txtTestNo.clear();
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ���� �˻�");
				alert.setHeaderText(searchName + " �л��� ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���.");
				alert.showAndWait();
			}
		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("�л� ���� �˻� ����");
			alert.setHeaderText("�л� ���� �˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���.");
			alert.showAndWait();
		}
	}

	// ���� ��ư
	public void handlerBtnreokAction(ActionEvent event) {
		TestModel sVo = null;
		TestDao sDao = null;
		TestModel TestEdit = totaltableview.getSelectionModel().getSelectedItem();
		selectedIndex = totaltableview.getSelectionModel().getSelectedIndex();
		if (event.getSource().equals(btnreok)) {
			sVo = new TestModel(txtTestNo.getText(), cbTestdivi.getSelectionModel().getSelectedItem(),
					cbsubjectdivi.getSelectionModel().getSelectedItem(), dptest.getValue() + "",
					Integer.parseInt(txtkorean.getText().trim()), Integer.parseInt(txtmath.getText().trim()),
					Integer.parseInt(txtenglish.getText().trim()), cbsubdivi.getSelectionModel().getSelectedItem(),
					Integer.parseInt(txtsubdivi.getText().trim()), Integer.parseInt(txtStu_num.getText().trim()));
			sDao = new TestDao();
			try {
				sDao.getTestUpdate(sVo, sVo.getTest_no());
			} catch (Exception e) {

				e.printStackTrace();
			}
			data.removeAll(data);
			totalList();
		}
	}

	// ������� â ���� ��ư �޼ҵ�
	public void handlerBtnma_viewAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/ManagerRegiview.fxml"));
			Parent View1 = (Parent) loader.load();
			Scene scane1 = new Scene(View1);
			Stage t1maintage = new Stage();
			t1maintage.setTitle("�������");
			t1maintage.setScene(scane1);
			Stage oldStage = (Stage) btnma_view.getScene().getWindow();
			oldStage.show();
			t1maintage.show();
		} catch (IOException e) {
			System.err.println("����" + e);
		}
	}

	// �л����â ���� ��ư �޼ҵ�
	public void handlerBtnst_viewAction(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/StudentRegiview.fxml"));
			Parent mainView2 = (Parent) loader.load();
			Scene scane2 = new Scene(mainView2);
			Stage maintage2 = new Stage();
			maintage2.setTitle("�л� ���");
			maintage2.setScene(scane2);
			Stage oldStage = (Stage) btnst_view.getScene().getWindow();
			oldStage.show();
			maintage2.show();
		} catch (IOException e) {

			System.err.println("����" + e);
		}

		// ���̵��н����� Ȯ���϶�� â

	}

	// �������� �˻� ��ư �޼ҵ�
	public void handlerBtnSearchAction(ActionEvent event) {
		// TODO Auto-generated method stub

	}

	public void init() {
		txtTestNo.clear();
		txtmath.clear();
		txtkorean.clear();
		txtenglish.clear();
		txtsubdivi.clear();
		cbsubdivi.getSelectionModel().clearSelection();
		cbTestdivi.getSelectionModel().clearSelection();
	}

	// ��ü ���� ����
	public void totalList() {
		Object[][] totalData;
		TestDao sDao = new TestDao();
		TestModel sVo = new TestModel();
		ArrayList<String> title;
		ArrayList<TestModel> list;
		title = sDao.getColumnName();
		int columnCount = title.size();
		list = sDao.getTestTotal();

		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			sVo = list.get(index);
			data.add(sVo);
		}
	}

	// �������� ��� ��ư �޼ҵ�
	public void handlerBtnokAction(ActionEvent event) {
		try {

			TestModel svo = null;
			TestDao sDao = null;

			data.removeAll(data);
			if (event.getSource().equals(btnok)) {
				svo = new TestModel(txtTestNo.getText(), cbTestdivi.getSelectionModel().getSelectedItem(),
						cbsubjectdivi.getSelectionModel().getSelectedItem(), dptest.getValue() + "",
						Integer.parseInt(txtkorean.getText().trim()), Integer.parseInt(txtmath.getText().trim()),
						Integer.parseInt(txtenglish.getText().trim()), cbsubdivi.getSelectionModel().getSelectedItem(),
						Integer.parseInt(txtsubdivi.getText().trim()), Integer.parseInt(txtStu_num.getText().trim()));
				sDao = new TestDao();
				sDao.getStudentregiste(svo);

				txtTestNo.clear();
				txtmath.clear();
				txtkorean.clear();
				txtenglish.clear();
				txtsubdivi.clear();
				cbsubdivi.getSelectionModel().clearSelection();
				cbTestdivi.getSelectionModel().clearSelection();
				if (sDao != null) {
					totalList();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ���� �Է�");
					alert.setHeaderText(txtTestNo.getText() + " ������ ������ ���������� �߰��Ǿ����ϴ�..");
					alert.setContentText("������ ������ �Է��ϼ���");
					alert.showAndWait();
				}
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� ���� �Է�");
				alert.setHeaderText("���� ������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
		} catch (Exception e) {
			e.getStackTrace();

		}
	}
}
