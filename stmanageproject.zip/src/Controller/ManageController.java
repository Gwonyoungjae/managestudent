package Controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.ManagerModel;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ManageController implements Initializable {

	@FXML
	private TextField txtstf_No;
	@FXML
	private TextField txtt_Name;
	@FXML
	private HBox imageBox;
	@FXML
	private DatePicker dpManager;
	@FXML
	private ComboBox<String> cbsubject;
	@FXML
	private CheckBox ckMon;
	@FXML
	private CheckBox ckTue;
	@FXML
	private CheckBox ckWed;
	@FXML
	private CheckBox ckThr;
	@FXML
	private CheckBox ckFri;
	@FXML
	private CheckBox ckSat;
	@FXML
	private CheckBox ckSun;
	@FXML
	private TextField txtf_grade;
	@FXML
	private TextField txtt_PHNO;
	@FXML
	private TextField txtt_add;
	@FXML
	private ComboBox<String> cbban;
	@FXML
	private Button btnresi;
	@FXML
	private Button btnserch;
	@FXML
	private Button btnview;
	@FXML
	private Button btnclose;
	@FXML
	private Button btnimageresi;
	@FXML
	private ImageView ImageView;
	@FXML
	private Button btndelete;
	@FXML
	private Button btnmodi;
	@FXML
	private TextField txtID;
	@FXML
	private PasswordField txtPW;
	@FXML
	private TableView<Model.ManagerModel> tableView = new TableView<>();

	Model.ManagerModel testModel = new Model.ManagerModel();
	ObservableList<Model.ManagerModel> data = FXCollections.observableArrayList();
	ObservableList<Model.ManagerModel> selectTestModel = null; // ���̺����� ������ ���� ����
	/* Model.TestModel staff = new Model.TestModel(); */
	int selectedIndex;
	String no;
	private Stage primaryStage;
	String selectFileName = ""; // �̹��� ���ϸ�
	String localUrl = ""; // �̹��� ���� ���
	Image localImage;
	File selectedFile = null;
	// �̹��� ó��
	// �̹��� ������ ������ �Ű������� ���� ��ü ����
	private File dirSave = new File("C:/images");
	// �̹��� �ҷ��� ������ ������ ���� ��ü ����
	private File file = null;

	// �⺻ �̹���
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// ��¥ ����� ����
		dpManager.setValue(LocalDate.now());

		// �̹����ʱ�ȭ
		localUrl = "/image/image.png";
		localImage = new Image(localUrl, false);
		ImageView.setImage(localImage);

		// �޺��ڽ� ����
		cbsubject.setItems(FXCollections.observableArrayList("��ü", "���", "����", "�ܱ���", "Ž������", "Ž����ȸ"));
		cbban.setItems(FXCollections.observableArrayList("��ü", "A", "B", "C", "D", "E"));
		// ��ư ����
		btnclose.setOnAction(event -> handlerBtncloseAction(event));
		btnimageresi.setOnAction(event -> handlerBtnImageFileActoion(event)); // �̹�������â
		btnresi.setOnAction(event -> handlerBtnresiAction(event));
		btnserch.setOnAction(event -> handlerBtnserchAction(event));
		btnview.setOnAction(event -> handlerBtnviewAction(event));
		btndelete.setOnAction(event -> handlerBtndeleteAction(event));
		btnmodi.setOnAction(event -> handlerBtnmodiAction(event));

		// ���̺� �� �÷��̸� ����
		TableColumn colStfNo = new TableColumn("No");
		colStfNo.setMaxWidth(40);
		colStfNo.setStyle("-fx-allignment: CENTER");
		colStfNo.setCellValueFactory(new PropertyValueFactory<>("stf_No"));
		TableColumn colt_Name = new TableColumn("�����̸�");
		colt_Name.setMaxWidth(60);
		colt_Name.setStyle("-fx-allignment: CENTER");
		colt_Name.setCellValueFactory(new PropertyValueFactory<>("t_Name"));
		TableColumn colsubject = new TableColumn("����");
		colsubject.setMinWidth(50);
		colsubject.setCellValueFactory(new PropertyValueFactory<>("subject"));
		TableColumn colf_grade = new TableColumn("�����з�");
		colf_grade.setMinWidth(50);
		colf_grade.setCellValueFactory(new PropertyValueFactory<>("f_grade"));
		TableColumn colt_PHNO = new TableColumn("������ȭ��ȣ");
		colt_PHNO.setMinWidth(90);
		colt_PHNO.setCellValueFactory(new PropertyValueFactory<>("t_PHNO"));
		TableColumn colban = new TableColumn("��");
		colban.setMinWidth(40);
		colban.setCellValueFactory(new PropertyValueFactory<>("ban"));

		tableView.getColumns().addAll(colStfNo, colt_Name, colsubject, colf_grade, colt_PHNO, colban);
		totalList();
		tableView.setItems(data);
		// ���̺� ���ñ�� �޼ҵ�
		tableView.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				selectTestModel = tableView.getSelectionModel().getSelectedItems();
				selectedIndex = tableView.getSelectionModel().getSelectedIndex();
				no = selectTestModel.get(0).getStf_No();
				try {
					txtstf_No.setText(selectTestModel.get(0).getStf_No());
					txtt_Name.setText(selectTestModel.get(0).getT_Name());
					dpManager.setUserData(selectTestModel.get(0).getDpManager());
					cbsubject.setValue(selectTestModel.get(0).getSubject());
					ImageView.setStyle(selectTestModel.get(0).getImageView());
					txtf_grade.setText(selectTestModel.get(0).getF_grade());
					txtt_PHNO.setText(selectTestModel.get(0).getT_PHNO());
					txtt_add.setText(selectTestModel.get(0).getT_add());
					cbban.setValue(selectTestModel.get(0).getBan());
					/*
					 * if (selectTestModel.get(0).get().equals("����")) { rbMale.setSelected(true);
					 * rbFemale.setDisable(true); } else { rbFemale.setSelected(true);
					 * rbMale.setDisable(true); } txtName.setEditable(false);
					 * txtBan.setEditable(false); cbYear.setDisable(true);
					 * btnDelete.setDisable(false); editDelete = true;
					 */
				} catch (Exception e) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("���� ���� ���� ����");
					alert.setHeaderText("���� ������ �Է��Ͻÿ�.");
					alert.setContentText("�������� �����ϼ���!");
					alert.showAndWait();
				}
			}
		});
	}

	public void handlerBtncloseAction(ActionEvent event) {
		Platform.exit();

	}

	// ������� ��ư
	public void handlerBtnresiAction(ActionEvent event) {

		try {
			ManagerModel svo = null;
			ManagerDao sDao = null;

			if (event.getSource().equals(btnresi)) {
				svo = new ManagerModel(txtstf_No.getText(), txtt_Name.getText(), dpManager.getValue() + "",
						cbsubject.getSelectionModel().getSelectedItem(), (String) ImageView.getUserData(),
						txtf_grade.getText(), txtt_PHNO.getText(), txtt_add.getText(),
						cbban.getSelectionModel().getSelectedItem());
				sDao = new ManagerDao();
				sDao.getStudentregiste(svo);

				data.removeAll(data);
				if (sDao != null) {
					totalList();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ���� �Է�");
					alert.setHeaderText(txtt_Name.getText() + " ������ ������ ���������� �߰��Ǿ����ϴ�..");
					alert.setContentText("���� �л��� ������ �Է��ϼ���");
					alert.showAndWait();

				}
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�л� ���� �Է�");
				alert.setHeaderText("���� ������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
		} catch (Exception e) {
			e.getStackTrace();

		}
	}

	// ���� ��ü
	public void totalList() {
		Object[][] totalData;
		ManagerDao sDao = new ManagerDao();
		ManagerModel sVo = new ManagerModel();
		ArrayList<String> title;
		ArrayList<ManagerModel> list;
		title = sDao.getColumnName();
		int columnCount = title.size();
		list = sDao.getManagerTotal();

		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			sVo = list.get(index);
			data.add(sVo);
		}
	}

	// ����
	public void handlerBtnmodiAction(ActionEvent event) {

		ManagerModel sVo = null;
		ManagerDao sDao = null;
		selectedIndex = tableView.getSelectionModel().getSelectedIndex();

		if (event.getSource().equals(btnmodi)) {
			sVo = new ManagerModel(txtID.getText(), txtPW.getText(), txtstf_No.getText(), txtt_Name.getText(),
					dpManager.getValue() + "", cbsubject.getSelectionModel().getSelectedItem(),
					(String) ImageView.getUserData(), txtf_grade.getText(), txtt_PHNO.getText(), txtt_add.getText(),
					cbban.getSelectionModel().getSelectedItem());
			sDao = new ManagerDao();

			txtstf_No.clear();
			txtt_Name.clear();
			cbsubject.getSelectionModel().clearSelection();

			txtf_grade.clear();
			txtt_PHNO.clear();
			txtt_add.clear();

			try {
				sDao.getManagerUpdate(sVo, sVo.getStf_No());
			} catch (Exception e) {

				e.printStackTrace();
			}
			data.removeAll(data);
			totalList();
		}
	}

	// ���̺��� ���� ���� ���� ���â �޼ҵ�
	public void handlerBtnviewAction(ActionEvent event) {
		try {

			FXMLLoader loader = new FXMLLoader();

			loader.setLocation(getClass().getResource("/View/ManagerCheck.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);

			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnview.getScene().getWindow());
			dialog.setTitle("����������ȸ");
			Parent parentEdit = (Parent) loader.load();
			Model.ManagerModel managerview = tableView.getSelectionModel().getSelectedItem();
			selectedIndex = tableView.getSelectionModel().getSelectedIndex();

			TextField editstf_No = (TextField) parentEdit.lookup("#txtStf_no");
			TextField editt_Name = (TextField) parentEdit.lookup("#txtT_name");
			DatePicker editdpManager = (DatePicker) parentEdit.lookup("#dpManager");
			ComboBox editsubject = (ComboBox) parentEdit.lookup("#cbSubject");
			ImageView editimage = (ImageView) parentEdit.lookup("#ImageView");
			TextField editf_grade = (TextField) parentEdit.lookup("#txtf_grade");
			TextField editt_PHNO = (TextField) parentEdit.lookup("#txtt_PHNO");
			TextField editt_add = (TextField) parentEdit.lookup("#txtt_add");
			ComboBox editban = (ComboBox) parentEdit.lookup("#cbban");

			System.out.println("1");
			editstf_No.setDisable(true);
			System.out.println("2");
			editt_Name.setDisable(true);
			editdpManager.setDisable(true);
			editsubject.setDisable(true);
			editimage.setDisable(true);
			editf_grade.setDisable(true);
			editt_PHNO.setDisable(true);
			editt_add.setDisable(true);
			editban.setDisable(true);

			editstf_No.setText(managerview.getStf_No());
			editt_Name.setText(managerview.getT_Name());
			editdpManager.setUserData(managerview.getDpManager());
			editsubject.setUserData(managerview.getSubject());
			editimage.setUserData(managerview.getImageView());
			editf_grade.setText(managerview.getF_grade());
			editt_PHNO.setText(managerview.getT_PHNO());
			editt_add.setText(managerview.getT_add());
			editban.setUserData(managerview.getBan());

			Button btnclose = (Button) parentEdit.lookup("#btnclose");
			// btnFormAdd.setDisable(true);
			// ��� ��ư �̺�Ʈ ó��
			/*
			 * btnCal.setOnAction(e -> { int sum = Integer.parseInt(editKorean.getText()) +
			 * Integer.parseInt(editEnglish.getText()) +
			 * Integer.parseInt(editMath.getText()) + Integer.parseInt(editSic.getText()) +
			 * Integer.parseInt(editSoc.getText()) + Integer.parseInt(editMusic.getText());
			 * double avg = sum / 6.0; editTotal.setText(sum + ""); editAvg.setText(avg +
			 * ""); btnCal.setDisable(true); btnFormAdd.setDisable(false); });
			 */
			// ���̾� �α� ���� ��ư �̺�Ʈ ó��
			/*
			 * btnFormAdd.setOnAction(e -> { TextField txtName = (TextField)
			 * parentEdit.lookup("#txtName"); TextField txtYear = (TextField)
			 * parentEdit.lookup("#txtYear"); TextField txtBan = (TextField)
			 * parentEdit.lookup("#txtBan"); TextField txtGender = (TextField)
			 * parentEdit.lookup("#txtGender"); TextField txtKorean = (TextField)
			 * parentEdit.lookup("#txtKorean"); TextField txtEnglish = (TextField)
			 * parentEdit.lookup("#txtEnglish"); TextField txtMath = (TextField)
			 * parentEdit.lookup("#txtMath"); TextField txtSic = (TextField)
			 * parentEdit.lookup("#txtSic"); TextField txtSoc = (TextField)
			 * parentEdit.lookup("#txtSoc"); TextField txtMusic = (TextField)
			 * parentEdit.lookup("#txtMusic"); TextField txtTotal = (TextField)
			 * parentEdit.lookup("#txtTotal"); TextField txtAvg = (TextField)
			 * parentEdit.lookup("#txtAvg"); data.remove(selectedIndex);
			 * data.add(selectedIndex, new TestModel(txtName.getText(), txtYear.getText(),
			 * txtBan.getText(), txtGender.getText(), txtKorean.getText(),
			 * txtEnglish.getText(), txtMath.getText(), txtSic.getText(), txtSoc.getText(),
			 * txtMusic.getText(), txtTotal.getText(), txtAvg.getText())); dialog.close();
			 * btnDelete.setDisable(true); btnEdit.setDisable(true); });
			 */
			// ���̾� �α� ��� ��ư �̺�Ʈ ó��
			btnclose.setOnAction(e -> {
				/*
				 * btnDelete.setDisable(true); btnEdit.setDisable(true);
				 */ dialog.close();
			});
			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();
		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}

	// �˻� ��ư �޼ҵ�
	public void handlerBtnserchAction(ActionEvent event) {

		if (txtstf_No.getText().trim().equals("") && txtt_Name.getText().trim().equals("")
				&& cbsubject.getSelectionModel().getSelectedItem().trim().equals("��ü")
				&& txtf_grade.getText().trim().equals("") && txtt_PHNO.getText().trim().equals("")
				&& cbban.getSelectionModel().getSelectedItem().trim().equals("")) {
			tableView.lookupAll(localUrl);
		}

		for (ManagerModel list : data) {
			if ((list.getStf_No()).equals(txtstf_No.getText())) {
				tableView.getSelectionModel().select(list);
			}
			if ((list.getT_Name()).equals(txtt_Name.getText())) {
				tableView.getSelectionModel().select(list);
			}
			if ((list.getSubject()).equals(cbsubject.getSelectionModel().getSelectedItem())) {
				tableView.getSelectionModel().select(list);
			}
			if ((list.getF_grade()).equals(txtf_grade.getText())) {
				tableView.getSelectionModel().select(list);
			}
			if ((list.getT_PHNO()).equals(txtt_PHNO.getText())) {
				tableView.getSelectionModel().select(list);
			}
			if ((list.getBan()).equals(cbban.getSelectionModel().getSelectedItem())) {
				tableView.getSelectionModel().select(list);
			}

		}
	}

	// ���� ��ư �޼ҵ�
	public void handlerBtndeleteAction(ActionEvent event) {
		ManagerDao sDao = new ManagerDao();
		ManagerModel sVo = new ManagerModel();

		try {

			sDao.getstaff(no);

			data.removeAll(data);
			// �л� ��ü ����
			totalList();

			txtstf_No.setEditable(true);
			txtt_Name.setEditable(true);

			txtf_grade.setEditable(true);
			txtt_PHNO.setEditable(true);

			txtstf_No.clear();
			txtt_Name.clear();
			cbsubject.getSelectionModel().clearSelection();

			txtf_grade.clear();
			txtt_PHNO.clear();
			txtt_add.clear();
		} catch (Exception e) {
			System.out.println(e);

		}

	}

	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	/***********************************************************
	 * imageDelete() �̹��� ���� �޼ҵ�.
	 *
	 * @param (������
	 *            ���ϸ�)
	 * @return �������θ� ����
	 ***********************************************************/
	public boolean imageDelete(String fileName) {
		boolean result = false;
		try {
			File fileDelete = new File(dirSave.getAbsolutePath() + "\\" + fileName); // �����̹��� ����
			if (fileDelete.exists() && fileDelete.isFile()) {
				result = fileDelete.delete();
				// �⺻ �̹���
				localUrl = "/image/image.png";
				localImage = new Image(localUrl, false);
				ImageView.setImage(localImage);
			}
		} catch (Exception ie) {
			System.out.println("ie = [ " + ie.getMessage() + "]");
			result = false;
		}
		return result;
	}

	/***********************************************************
	 * imageSave() �̹��� ���� �޼ҵ�.
	 *
	 * @param (�о��
	 *            ���� ��ü)
	 ***********************************************************/
	public String imageSave(File file) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		int data = -1;
		String fileName = null;
		try {
			// �̹��� ���ϸ� ����
			fileName = "TestModel" + System.currentTimeMillis() + "_" + file.getName();
			bis = new BufferedInputStream(new FileInputStream(file));
			bos = new BufferedOutputStream(new FileOutputStream(dirSave.getAbsolutePath() + "\\" + fileName));
			// ������ �̹��� ���� InputStream�� �������� �̸����� ���� -1
			while ((data = bis.read()) != -1) {
				bos.write(data);
				bos.flush();
			}
		} catch (Exception e) {
			e.getMessage();
		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
				if (bis != null) {
					bis.close();
				}
			} catch (IOException e) {
				e.getMessage();
			}
		}
		return fileName;
	}

	// �̹��� ���� ���� â
	public void handlerBtnImageFileActoion(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Image File", "*.png", "*.jpg", "*.gif"));
		try {
			selectedFile = fileChooser.showOpenDialog(primaryStage);
			if (selectedFile != null) {
				// �̹��� ���� ���
				localUrl = selectedFile.toURI().toURL().toString();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		localImage = new Image(localUrl, false);
		ImageView.setImage(localImage);
		ImageView.setFitHeight(150);
		ImageView.setFitWidth(120);
		btnimageresi.setDisable(false);
		if (selectedFile != null) {
			selectFileName = selectedFile.getName();
		}
	}

}
