package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.ManagerModel;
import Model.StudentModel;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class ManagerDao {

	public ManagerModel getStudentregiste(ManagerModel svo) throws Exception {
		// �� ������ ó���� ���� SQL ��
		String dml = "insert into staff "
				+ "(id, pw, stf_no,t_name, dpManager, subject,imageview,f_grade,t_phno,t_add,ban)" + " values "
				+ "( ?, ?, ?, ?,?, ?, ?, ?,?,?,? )";
		Connection con = null;
		PreparedStatement pstmt = null;
		ManagerModel retval = null;

		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml.toString());

			pstmt.setString(1, svo.getID());
			pstmt.setString(2, svo.getPW());
			pstmt.setString(3, svo.getStf_No());
			pstmt.setString(4, svo.getT_Name());
			pstmt.setString(5, svo.getDpManager());
			pstmt.setString(6, svo.getSubject());
			pstmt.setString(7, svo.getImageView());
			pstmt.setString(8, svo.getF_grade());
			pstmt.setString(9, svo.getT_PHNO());
			pstmt.setString(10, svo.getT_add());
			pstmt.setString(11, svo.getBan());
			int i = pstmt.executeUpdate();
			retval = new ManagerModel();

		} catch (SQLException e) {
			e.getStackTrace();
			System.out.println("e=[" + e + "]");
			System.out.println("ee");
		} catch (Exception e) {
			e.getStackTrace();
			System.out.println("e=[" + e + "]");
			System.out.println("eee");
		} finally {
			try {
				// �� �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;
	}

	public ArrayList<ManagerModel> getManagerTotal() {
		ArrayList<ManagerModel> list = new ArrayList<ManagerModel>();
		StringBuffer sql = new StringBuffer();
		sql.append("select id,pw,stf_No, t_name, dpManager, subject, imageview, f_grade,t_phno, t_add,ban ");
		sql.append(" from staff order by stf_No desc");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ManagerModel sVo = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				sVo = new ManagerModel();
				sVo.setStf_No(rs.getString("stf_No"));
				sVo.setT_Name(rs.getString("t_Name"));
				sVo.setDpManager(rs.getString("dpManager"));
				sVo.setSubject(rs.getString("subject"));
				sVo.setImageView(rs.getString("imageView"));
				sVo.setF_grade(rs.getString("f_grade"));
				sVo.setT_PHNO(rs.getString("t_PHNO"));
				sVo.setT_add(rs.getString("t_add"));
				sVo.setBan(rs.getString("ban"));

				list.add(sVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
		return list;
	}
	
	//���� �޼ҵ�
	public ManagerModel getManagerUpdate(ManagerModel sVo,String stf_no) throws Exception {
		// �� ������ ó���� ���� SQL ��
		StringBuffer sql = new StringBuffer();
		sql.append("update staff set ");
		sql.append(" id=?, pw=?, stf_no=?, t_name=?, dpManager=?, subject=?, imageview=?, f_grade=?,t_phno=?,t_add=?,ban=? ");
		sql.append(" where stf_no = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		ManagerModel retval = null;
		try {
			// �� DBUtil�̶�� Ŭ������ getConnection( )�޼���� �����ͺ��̽��� ����
			con = DBUtil.getConnection();
			// �� ������ �л� ������ �����ϱ� ���Ͽ� SQL������ ����
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, sVo.getID());
			pstmt.setString(2, sVo.getPW());
			pstmt.setString(3, sVo.getStf_No());
			pstmt.setString(4, sVo.getT_Name());
			pstmt.setString(5, sVo.getDpManager());
			pstmt.setString(6, sVo.getSubject());
			pstmt.setString(7, sVo.getImageView());
			pstmt.setString(8, sVo.getF_grade());
			pstmt.setString(9, sVo.getT_PHNO());
			pstmt.setString(10, sVo.getT_add());
			pstmt.setString(11, sVo.getBan());
		    pstmt.setString(12, sVo.getStf_No());
			
			// �� SQL���� ������ ó�� ����� ����
			int i = pstmt.executeUpdate();
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� �Ϸ�.");
				alert.setContentText("���� ���� ����!!!");
				alert.showAndWait();
				retval = new ManagerModel();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� ����.");
				alert.setContentText("���� ���� ����!!!");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				// �� �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;
	}

	public void getstaff(String stf_no) {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from staff where stf_no = ? ");
		

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			ps = con.prepareStatement(sql.toString());
			ps.setString(1, stf_no);

			int i = ps.executeUpdate();

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
	}
	

	// �����ͺ��̽����� �л� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from Staff");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
		return columnName;
	}
}
