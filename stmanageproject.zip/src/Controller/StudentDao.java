package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.ManagerModel;
import Model.StudentModel;
import Model.TestModel;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class StudentDao {
	public StudentModel getStudentregiste(StudentModel svo) throws Exception {
		// �� ������ ó���� ���� SQL ��
		String dml = "insert into student " + "(stu_no, s_name, a_grade,s_subject, s_grade, ban,s_uni,s_ati)"+ " values " + "( ?, ?, ?, ?, ?, ?, ?, ? )";
		Connection con = null;
		PreparedStatement pstmt = null;
		StudentModel retval = null;

		try {
		
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml.toString());

			pstmt.setInt(1, svo.getStu_no());
			pstmt.setString(2, svo.getS_name());
			pstmt.setString(3, svo.getA_grade());
			pstmt.setString(4, svo.getS_Subject());
			pstmt.setString(5, svo.getS_grade());
			pstmt.setString(6, svo.getBan());
			pstmt.setString(7, svo.getS_uni());
			pstmt.setString(8, svo.getS_ati());
			int i = pstmt.executeUpdate();
			retval = new StudentModel();

		} catch (SQLException e) {
			e.getStackTrace();
			System.out.println("e=[" + e + "]");
			System.out.println("ee");
		} catch (Exception e) {
			e.getStackTrace();
			System.out.println("e=[" + e + "]");
			System.out.println("eee");
		} finally {
			try {
				// �� �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;
	}
	//��ü ����Ʈ
	public ArrayList<StudentModel> getStudentTotal() {
		ArrayList<StudentModel> list = new ArrayList<StudentModel>();
		StringBuffer sql = new StringBuffer();
		sql.append("select Stu_no,S_name,A_grade, S_Subject,S_grade, ban, S_uni, S_ati ");
		sql.append(" from student order by stu_No desc");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StudentModel sVo = null;
		try {
			
			
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				sVo = new StudentModel();
				sVo.setStu_no(rs.getInt("stu_no"));
				sVo.setS_name(rs.getString("S_name"));
				sVo.setA_grade(rs.getString("A_grade"));
				sVo.setS_Subject(rs.getString("S_Subject"));
				sVo.setS_grade(rs.getString("S_grade"));
				sVo.setBan(rs.getString("ban"));
				sVo.setS_uni(rs.getString("S_uni"));
				sVo.setS_ati(rs.getString("S_ati"));
				
				list.add(sVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
		return list;
	}
//���� �޼ҵ�
	public void getStudent(int Stu_no) {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from student where stu_no = ? ");
		

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			ps = con.prepareStatement(sql.toString());
			ps.setInt(1, Stu_no);

			int i = ps.executeUpdate();

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
	}
	//���� �޼ҵ�
	public StudentModel getTestUpdate(StudentModel svo,int stu_no) throws Exception {
		// �� ������ ó���� ���� SQL ��
		StringBuffer sql = new StringBuffer();
		sql.append("update student set ");
		sql.append(" Stu_No=?, S_name=?, A_grade=?, S_subject=?, s_grade=?, ban=?, s_uni=?, s_ati=? ");
		sql.append(" where stu_no = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		StudentModel retval = null;
		try {
			// �� DBUtil�̶�� Ŭ������ getConnection( )�޼���� �����ͺ��̽��� ����
			con = DBUtil.getConnection();
			// �� ������ �л� ������ �����ϱ� ���Ͽ� SQL������ ����
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, svo.getStu_no());
			pstmt.setString(2, svo.getS_name());
			pstmt.setString(3, svo.getA_grade());
			pstmt.setString(4, svo.getS_Subject());
			pstmt.setString(5, svo.getS_grade());
			pstmt.setString(6, svo.getBan());
			pstmt.setString(7, svo.getS_uni());
			pstmt.setString(8, svo.getS_ati());
			pstmt.setInt(9, svo.getStu_no());
			
			// �� SQL���� ������ ó�� ����� ����
			int i = pstmt.executeUpdate();
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� �Ϸ�.");
				alert.setContentText("���� ���� ����!!!");
				alert.showAndWait();
				retval = new StudentModel();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� ����.");
				alert.setContentText("���� ���� ����!!!");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				// �� �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;
	}

	// �����ͺ��̽����� �л� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName3 = new ArrayList<String>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from Student");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName3.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
		return columnName3;
	}
}

